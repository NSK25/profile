/* Start Skills */
    $('#circle1').circleProgress({
        value: 0.90,
        size: 150,
        fill: {
            gradient: ["#2EBBE6"]
        }
    });
    $('#circle2').circleProgress({
        value: 0.75,
        size: 150,
        fill: {
            gradient: ["#D74681"]
        }
    });
    $('#circle3').circleProgress({
        value: 0.70,
        size: 150,
        fill: {
            gradient: ["#75DECC"]
        }
    });
    $('#circle4').circleProgress({
        value: 0.85,
        size: 150,
        fill: {
            gradient: ["#EB7D4A"]
        }
    });
/* End Skills */
/* Start Portfolio */
$(function(){

	// Instantiate MixItUp:

	$('#Container').mixItUp();

});
/* End Portfolio */