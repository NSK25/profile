import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.scss']
})
export class AppHeaderComponent implements OnInit {
  name             =     "Sai krishna Nadella";
  positionName     =     "Full Stack Developer|Front-End Developer";
  address          =     "";
  mobileNumber     =     "+1 704-904-9394";
  email            =     "saikrishnanadella1@gmail.com";
  websiteName      =     "www.saikrishna.com";
  websiteLink      =     "http://www.*******.com";

  constructor() { }

  ngOnInit() {
  }

}
