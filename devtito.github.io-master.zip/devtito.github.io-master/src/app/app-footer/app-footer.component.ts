import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './app-footer.component.html',
  styleUrls: ['./app-footer.component.scss']
})
export class AppFooterComponent implements OnInit {
  socialIcon = [
    {
      link : 'https://www.facebook.com/saikrishna.nadella.5',
      icon : 'fa fa-facebook'
    },
    {
      link : 'https://twitter.com/KrishnaNadella',
      icon : 'fa fa-twitter'
    },
    {
      link : 'https://www.linkedin.com/in/saikrishna1995/',
      icon : 'fa fa-linkedin'
    },
    {
      link : 'https://github.com/NSK25',
      icon : 'fa fa-github'
    },
    
    {
      link : 'https://www.instagram.com/saikrishna_nadella/',
      icon : 'fa fa-instagram'
    },
  ]
  constructor() { }

  ngOnInit() {
  }

}
