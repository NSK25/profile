import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-experiance',
  templateUrl: './experiance.component.html',
  styleUrls: ['./experiance.component.scss']
})
export class ExperianceComponent implements OnInit {
  experianceTitle = "experiance";
  companies = [
    {
      position : 'Research Assitant',
      name : 'University of North Carolina at Charlotte',
      date : 'April 2017 - Present',
      description: ' Worked on existing web application of School of Nursing on both front-end and back-end as a full stack developer.',
      
    },
    {
      position : 'Software Developer',
      name : 'Infosys',
      date : 'Jan 2017 - Jul 2017',
      description: 'Responsible for developing web application using angular 2,Java,MySql,Hibernate.',
      
    },
    {
      position : 'Research And Development Coordinator',
      name : 'KL University',
      date : 'Aug 2015 - Sep 2016',
      description: 'Responsible for developing web application for the Software Engineering Associates club of Computer Science using, HTML5, CSS3, Bootstrap, JSP, Java, MySQL.',
      
    },
    
  ]
  constructor() { }

  ngOnInit() {
  }

}
