import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.scss']
})
export class PortfolioComponent implements OnInit {
  portfolio = [
    {
      name : "Uncc news ",
      link : "http://ninernews.s3-website-us-east-1.amazonaws.com/",
      imagePath: "assets/images/portfolio/",
      image : "screenmix" + ".png",
      companyName : "@mywork",
      companyLink : "https://github.com/NSK25/Uncc-News",
    },
    {
      name : "React NBA",
      link : "http://nba-app.s3-website-us-east-1.amazonaws.com/",
      imagePath: "assets/images/portfolio/",
      image : "abeqtisad" + ".png",
      companyName : "@mywork",
      companyLink : "https://github.com/NSK25/ReactNBA",
    },
   
    {
      name : "Ecommerce Application",
      link : "https://github.com/NSK25/Ecommerceapplication",
      imagePath: "assets/images/portfolio/",
      image : "archfurp" + ".png",
      companyName : "@CourseWork",
      companyLink : "https://github.com/NSK25/Ecommerceapplication",
    },
    {
      name : "Internship Managment System",
      link : "https://github.com/NSK25/spring-framework",
      imagePath: "assets/images/portfolio/",
      image : "cuda" + ".png",
      companyName : "Nun",
      companyLink : "Nun",
    },
    {
      name : "Books-Author Rest Api",
      link : "https://github.com/NSK25/Book-authors-rest-API",
      imagePath: "assets/images/portfolio/",
      image : "cuda" + ".png",
      companyName : "Nun",
      companyLink : "Nun",
    },
    
  ]
  constructor() { }

  ngOnInit() {
  }

}
