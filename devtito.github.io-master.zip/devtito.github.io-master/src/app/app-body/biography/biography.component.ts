import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-biography',
  templateUrl: './biography.component.html',
  styleUrls: ['./biography.component.scss']
})
export class BiographyComponent implements OnInit {
  bioTitle = "portfolio";
  name = "Sai Krishna Nadella";
  positionName = "Full stack Developer";
  developmentPosition = "Front-End Development";
  education = "University of North Carolina at charlotte";
  expYears = 2 + " Years";
  age = 23 + "Years old";
  social = [
    {
      name : "@jsdevelop",
      link : "https://www.facebook.com/saikrishna.nadella.5",
      icon : "fa fa-facebook",
      siteName : "Facebook"
    },
    {
      name : "@jsdevelop",
      link : "https://www.linkedin.com/in/saikrishna1995/",
      icon : "fa fa-linkedin",
      siteName : "Linkedin"
    },
   
    {
      name : "@mahmoudemad23",
      link : "https://twitter.com/KrishnaNadella",
      icon : "fa fa-twitter",
      siteName : "Twitter"
    },
    {
      name : "@jsdevelop",
      link : "https://www.instagram.com/saikrishna_nadella/",
      icon : "fa fa-instagram",
      siteName : "Instagram"
    },
  ];
  constructor() {
  }

  ngOnInit() {
  }

}
