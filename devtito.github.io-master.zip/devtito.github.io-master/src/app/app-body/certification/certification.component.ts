import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-certification',
  templateUrl: './certification.component.html',
  styleUrls: ['./certification.component.scss']
})
export class CertificationComponent implements OnInit {
  certifications = [
    {
      name : 'Certified Aws Developer-associate',
      date : '2018',
      url : 'https://aws.amazon.com/certification/ ',
      company : 'Amazon Web Service',
    },
    
  ]
  constructor() { }

  ngOnInit() {
  }

}
