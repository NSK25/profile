import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onePagePortfolio',
  templateUrl: './onepage-portfolio.component.html',
  styleUrls: ['./onepage-portfolio.component.scss']
})
export class OnepagePortfolioComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
